var lab="mycache";
var assets=[
    "/",
    "/index.html",
    "/sw.js",
    "/images432.png",
    "/images216.png",
    "/images108.png",
    "/manifest.json",
    "/data.json"
];



self.addEventListener("install",_event=>{
    caches.open(lab);
    then(caches =>{
        caches.addAll(assets);
    });
});

self.addEventListener("activate",_event=>{
console.log("Inside activate");
});

self.addEventListener("fetch",async event=>{

    console.log("inside fetch")
});